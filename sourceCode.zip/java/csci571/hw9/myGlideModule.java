package csci571.hw9;

import com.bumptech.glide.module.AppGlideModule;
import com.bumptech.glide.annotation.GlideModule;

@com.bumptech.glide.annotation.GlideModule
public class myGlideModule extends AppGlideModule {

}

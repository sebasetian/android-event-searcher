package csci571.hw9.schema;

public class Seatmap {
    public String staticUrl;
}

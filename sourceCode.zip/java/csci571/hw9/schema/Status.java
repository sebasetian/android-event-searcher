package csci571.hw9.schema;

public class Status {
    public String code;
}

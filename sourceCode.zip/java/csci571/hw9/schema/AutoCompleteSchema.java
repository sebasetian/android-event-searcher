package csci571.hw9.schema;

public class AutoCompleteSchema {
    public String name;
}

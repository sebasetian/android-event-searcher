package csci571.hw9.schema;

public class BoxOfficeInfo {
    public String openHoursDetail  = "";
    public String phoneNumberDetail  = "";
}

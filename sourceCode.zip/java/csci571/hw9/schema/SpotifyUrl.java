package csci571.hw9.schema;

public class SpotifyUrl {
    public String spotify = "";
}

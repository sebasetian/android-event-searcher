package csci571.hw9.schema;

public class ClassificationType {
    public String id;
    public String name;
}

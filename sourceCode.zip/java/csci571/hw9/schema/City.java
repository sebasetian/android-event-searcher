package csci571.hw9.schema;

public class City {
    public String name = "";
}

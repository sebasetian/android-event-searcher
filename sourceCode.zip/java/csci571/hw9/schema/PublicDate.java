package csci571.hw9.schema;

public class PublicDate {
    String startDateTime;
    String endDateTaime;
}

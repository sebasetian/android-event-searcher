package csci571.hw9.schema;

public class StartDate {
    public String localDate;
    public String localTime;
    String dateTime;
}

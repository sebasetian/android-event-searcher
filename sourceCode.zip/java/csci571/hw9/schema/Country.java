package csci571.hw9.schema;

public class Country extends City {

}

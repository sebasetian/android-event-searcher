package csci571.hw9.model;

import csci571.hw9.schema.SearchEventSchema;

public class ResultField {
    public String id;
    public SearchEventSchema event;
}

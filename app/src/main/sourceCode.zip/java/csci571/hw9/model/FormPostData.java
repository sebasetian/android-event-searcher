package csci571.hw9.model;

public class FormPostData {
    public String keyword;
    public String category;
    public int distance;
    public String distanceUnit;
    public double lat;
    public double lng;
}

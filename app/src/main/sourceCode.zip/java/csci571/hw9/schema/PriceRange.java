package csci571.hw9.schema;

public class PriceRange {
    public String type;
    public String currency;
    public double min;
    public double max;
}

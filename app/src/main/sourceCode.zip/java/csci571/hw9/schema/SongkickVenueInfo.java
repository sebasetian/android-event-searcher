package csci571.hw9.schema;

public class SongkickVenueInfo {
    public String displayName;
    public int id;
}

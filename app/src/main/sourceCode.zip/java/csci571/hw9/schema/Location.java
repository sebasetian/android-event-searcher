package csci571.hw9.schema;

public class Location {
    public String longitude;
    public String latitude;
}

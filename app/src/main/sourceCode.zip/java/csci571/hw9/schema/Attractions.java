package csci571.hw9.schema;

public class Attractions extends SearchEventSchema {
    String[] aliases;
}

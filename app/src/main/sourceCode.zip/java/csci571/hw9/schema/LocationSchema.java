package csci571.hw9.schema;

public class LocationSchema {
    public double lat;
    public double lng;
}

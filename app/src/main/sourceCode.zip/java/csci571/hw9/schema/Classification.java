package csci571.hw9.schema;

public class Classification {
    public ClassificationType segment;
    public ClassificationType genre;
    public ClassificationType subGenre;
    public ClassificationType type;
    public ClassificationType subType;

}

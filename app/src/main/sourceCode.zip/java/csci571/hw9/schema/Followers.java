package csci571.hw9.schema;

public class Followers {
    public String href = "";
    public int total = 0;
}

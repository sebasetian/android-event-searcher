package csci571.hw9.schema;

public class GeneralInfo {
    public String generalRule = "";
    public String childRule = "";
}

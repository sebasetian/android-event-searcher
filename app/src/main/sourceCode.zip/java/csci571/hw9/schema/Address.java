package csci571.hw9.schema;

public class Address {
    public String line1 = "";
    public String line2;
}

package csci571.hw9.schema;

public class Dates {
    public StartDate start;
    public Status status;
}

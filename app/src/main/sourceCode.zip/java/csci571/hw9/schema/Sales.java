package csci571.hw9.schema;

public class Sales {
    PublicDate pub;
}

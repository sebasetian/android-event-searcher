package csci571.hw9.schema;

public class CustomImg {
    public String link;
}

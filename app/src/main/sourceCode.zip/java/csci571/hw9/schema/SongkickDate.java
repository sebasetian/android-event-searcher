package csci571.hw9.schema;

public class SongkickDate {
    public String date = "";
    public String time = "";
}
